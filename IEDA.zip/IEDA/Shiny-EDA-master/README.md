# Shiny-EDA
Automated Exploratory Data Analysis Dashboard.

Users can load datasets (Excel , CSV or RDA) and perform data cleaning either by replacing NAs with Aggregated values or just dropping features if Na percentage is too high.

By selecting Dimensions and Measures, all kinds of plots (Univariate and Bivariate analysis) are generated using Plotly interactive Data visualizations.

![Alt text](EDA3.png?raw=true "Optional Title")

![Alt text](EDA2.png?raw=true "Optional Title")

![Alt text](EDA14.png?raw=true "Optional Title")
