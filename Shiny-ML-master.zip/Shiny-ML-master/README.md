# Shiny-ML
Automated Modeling and comparison with Cross-Validation (shiny dashboard)

![Alt text](1.png?raw=true "Optional Title")

![Alt text](2.png?raw=true "Optional Title")

![Alt text](4.png?raw=true "Optional Title")

![Alt text](5.png?raw=true "Optional Title")

![Alt text](6.png?raw=true "Optional Title")

![Alt text](10.png?raw=true "Optional Title")

![Alt text](12.png?raw=true "Optional Title")

![Alt text](13.png?raw=true "Optional Title")

![Alt text](15.png?raw=true "Optional Title")
