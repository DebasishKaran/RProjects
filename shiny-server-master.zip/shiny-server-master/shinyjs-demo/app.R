dir <- system.file("examples", "demo", package = "shinyjs")
setwd(dir)
shiny::shinyAppDir(".")
