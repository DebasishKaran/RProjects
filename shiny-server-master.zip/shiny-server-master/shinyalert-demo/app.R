dir <- system.file("examples", "demo", package = "shinyalert")
setwd(dir)
shiny::shinyAppDir(".")
