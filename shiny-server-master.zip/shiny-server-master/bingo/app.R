dir <- system.file("shiny", package = "bingo")
setwd(dir)
shiny::shinyAppDir(".")
