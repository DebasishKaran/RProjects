dir <- system.file("example", package = "timevis")
setwd(dir)
shiny::shinyAppDir(".")
