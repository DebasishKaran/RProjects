dir <- system.file("shiny", package = "epimatch")
setwd(dir)
shiny::shinyAppDir(".")
